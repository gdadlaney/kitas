from django.shortcuts import render
from django.http import HttpResponse

from django.db import connection

def index(request):
	return render(request, 'index.html',{})

def test(request):
	return HttpResponse("Hello")

def test2(request):
	#from django.db import connection

	user_ingredients = ['potato', 'onion', 'flour']
	ingredient_id_list = []

	# converts ingredient name to ingredient_id 
	with connection.cursor() as cursor:
		for i in range(user_ingredients.__len__()):
			#cursor.execute("select id from ingredients where name_english='%s'", user_ingredients[i]) does not work
			cursor.execute("select id from ingredients where name_english='"+user_ingredients[i]+"'")	
			ingredient_id = int(cursor.fetchone()[0])
			ingredient_id_list.append(ingredient_id)

	print(ingredient_id_list)

	#user_ingredients = [1, 2, 3]	#from the checkboxes, names will be mapped to id's	
	#recipes_matching = [[12, 13], [12], [11, 13], [13]]
	recipes_matching = []

	with connection.cursor() as cursor:
		for i in range(user_ingredients.__len__()):
			cursor.execute("select rec_id from rec_ingredients where ingr_id="+str(ingredient_id_list[i]))
			recipes = list(cursor.fetchall())		#how to correct this format? - ((1,), (2,), (3,))
			print(recipes)
			recipes_matching.append(recipes)

	print(recipes_matching)

	#recipes_matching - [((1,), (2,), (3,)), ((1,), (2,)), ((1,),)]
	
	# look for a better way to convert tuples to ints
	for i in range(recipes_matching.__len__()):
		for j in range(recipes_matching[i].__len__()):
			recipes_matching[i][j] = recipes_matching[i][j][0]

	print(recipes_matching)

	# recipes_matching - [[1, 2, 3], [1, 2], [1]]

	dict = {}

	for i in range(recipes_matching.__len__()):
		for j in range(recipes_matching[i].__len__()):
			if(not dict.__contains__(recipes_matching[i][j])):
				dict[recipes_matching[i][j]] = 1
			else:
				dict[recipes_matching[i][j]] += 1

	#print(dict)

	#sorting the dict in reverse order
	import operator
	sorted_dict = sorted(dict.items(), key=operator.itemgetter(1), reverse=True)
	print(sorted_dict)

	# sorted_dict - [(1, 3), (2, 2), (3, 1)]

	final_str = ""

	"""
	for i in range(recipes_matching.__len__()):
		final_str += str(sorted_dict[i][0]) + " : " + str(sorted_dict[i][1]) + "<br>" 
	"""

	with connection.cursor() as cursor:
		for i in range(sorted_dict.__len__()):
			final_str += "recipe id = "+str(sorted_dict[i][0]) + " : " + str(sorted_dict[i][1]) + " ingredients matched" + "<br>" 
			cursor.execute("select name, directions from recipes where id="+ str(sorted_dict[i][0]))
			recipe_desc = cursor.fetchone()
			print(recipe_desc)
			final_str += recipe_desc[0] + "<br>" + recipe_desc[1] + "<br><br>"

	print(final_str)

	return HttpResponse(final_str)


def customers(request):
	with connection.cursor() as cursor:
		cursor.execute("SELECT name FROM customers")
		row = cursor.fetchone()
	return HttpResponse(row)