from django.apps import AppConfig


class KitasConfig(AppConfig):
    name = 'kitas'
